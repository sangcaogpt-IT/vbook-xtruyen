function execute(url) {
    var response = fetch(url);
    if (!response.ok) return Response.error("Không tải được trang truyện: HTTP " + response.status);
    var doc = response.html();
    var h1 = doc.select("h1").first();
    var name = h1 ? h1.text().trim() : "XTruyen";
    var cover = "";
    var imgs = doc.select("img");
    for (var i = 0; i < imgs.size(); i++) {
        var im = imgs.get(i), alt = (im.attr("alt") || "").toLowerCase();
        var src = im.attr("data-src") || im.attr("src");
        if (src && (alt.indexOf(name.toLowerCase()) >= 0 || src.indexOf("cover") >= 0 || src.indexOf("truyen") >= 0)) { cover = src; break; }
    }
    var body = doc.select("body").first();
    var text = body ? body.text() : doc.text();
    var author = "";
    var m = text.match(/Tác giả\s*[:\-]?\s*([^\n\r]{1,80})/i);
    if (m) author = m[1].trim();
    var ongoing = !/Hoàn thành|Đã hoàn thành|Full/i.test(text);
    var description = "";
    var meta = doc.select('meta[name="description"]').first();
    if (meta) description = meta.attr("content") || "";
    return Response.success({name:name,cover:cover,host:"https://xtruyen.vn",author:author,description:description,detail:"",ongoing:ongoing});
}