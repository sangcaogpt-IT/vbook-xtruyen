function execute(url) {
    var response = fetch(url);
    if (!response.ok) return Response.error("Không tải được trang truyện: HTTP " + response.status);
    var doc = response.html();

    var h1 = doc.select("h1").first();
    var name = h1 ? h1.text().trim() : "XTruyen";

    var cover = "";
    var imgs = doc.select("img");
    for (var i = 0; i < imgs.size(); i++) {
        var im = imgs.get(i);
        var alt = (im.attr("alt") || "").toLowerCase();
        var src = im.attr("data-src") || im.attr("src");
        if (src && (alt.indexOf(name.toLowerCase()) >= 0 || src.indexOf("cover") >= 0 || src.indexOf("truyen") >= 0)) {
            cover = src; break;
        }
    }

    var text = doc.body().text();
    var author = "";
    var m = text.match(/Tác giả\s*[:\-]?\s*([^\n\r]{1,80})/i);
    if (m) author = m[1].trim();

    var ongoing = !/Hoàn thành|Đã hoàn thành|Full/i.test(text);

    var description = "";
    var heads = doc.select("h2,h3,h4");
    for (var j = 0; j < heads.size(); j++) {
        var t = heads.get(j).text();
        if (/GIỚI THIỆU|GIỚI THIỆU TRUYỆN|NỘI DUNG/i.test(t)) {
            var n = heads.get(j).nextElementSibling();
            var parts = [];
            var count = 0;
            while (n && count < 8) {
                if (/^H[1-6]$/.test(n.tagName().toUpperCase())) break;
                var nt = n.text().trim();
                if (nt) parts.push(nt);
                n = n.nextElementSibling();
                count++;
            }
            description = parts.join("\n");
            break;
        }
    }
    if (!description) {
        var meta = doc.select("meta[name=description]").first();
        if (meta) description = meta.attr("content");
    }

    return Response.success({
        name: name,
        cover: cover,
        host: "https://xtruyen.vn",
        author: author,
        description: description,
        detail: "",
        ongoing: ongoing
    });
}