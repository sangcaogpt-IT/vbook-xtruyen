function execute(url) {
    var response = fetch(url);
    if (!response.ok) return Response.error("Không tải được mục lục: HTTP " + response.status);
    var doc = response.html();
    var links = doc.select("a[href]");
    var out = [];
    var seen = {};
    for (var i = 0; i < links.size(); i++) {
        var a = links.get(i);
        var href = a.absUrl("href");
        if (!href) href = a.attr("href");
        var name = a.text().trim();
        if (/\/truyen\/[^\/]+\/chuong-[^\/?#]+\/?/i.test(href) && !seen[href]) {
            if (!name) {
                var mm = href.match(/chuong-([^\/?#]+)/i);
                name = mm ? "Chương " + mm[1] : "Chương";
            }
            seen[href] = true;
            out.push({ name: name, url: href });
        }
    }
    if (out.length === 0) return Response.error("Không tìm thấy danh sách chương trên trang.");
    return Response.success(out);
}