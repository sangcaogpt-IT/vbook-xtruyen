function execute(url) {
    var response = fetch(url);
    if (!response.ok) return Response.error("Không tải được mục lục: HTTP " + response.status);
    var doc = response.html(), links = doc.select("a[href]"), out = [], seen = {};
    for (var i=0;i<links.size();i++) { var a=links.get(i), href=a.absUrl("href")||a.attr("href"), name=a.text().trim();
      if (/\/truyen\/[^\/]+\/chuong-[^\/?#]+\/?/i.test(href) && !seen[href]) { if(!name){var mm=href.match(/chuong-([^\/?#]+)/i);name=mm?"Chương "+mm[1]:"Chương";} seen[href]=true; out.push({name:name,url:href,host:"https://xtruyen.vn"}); }}
    if (!out.length) return Response.error("Không tìm thấy danh sách chương trên trang.");
    return Response.success(out);
}