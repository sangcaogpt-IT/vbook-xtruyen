function execute(url) {
    var response = fetch(url);
    if (!response.ok) return Response.error("Không tải được chương: HTTP " + response.status);
    var doc = response.html();

    var candidates = [
        ".chapter-content", ".chapter-c", ".chapter-text", ".reading-content",
        ".entry-content", ".post-content", ".content-chapter", "#chapter-content",
        "#chapter-c", "#reading-content", "article"
    ];
    var el = null;
    for (var i = 0; i < candidates.length; i++) {
        var x = doc.select(candidates[i]).first();
        if (x && x.text().trim().length > 200) { el = x; break; }
    }

    if (!el) {
        var all = doc.select("div");
        var best = null, bestLen = 0;
        for (var j = 0; j < all.size(); j++) {
            var d = all.get(j);
            var txt = d.text().trim();
            if (txt.length > bestLen && !/TRÌNH ĐỌC TTS|TRUYỆN HAY|CẢM NGHĨ CỦA BẠN/i.test(txt.substring(0, 150))) {
                best = d; bestLen = txt.length;
            }
        }
        el = best;
    }
    if (!el) return Response.error("Không tìm thấy nội dung chương.");

    el.select("script,style,iframe,form,button,select,input,nav,footer,header,.comments,.comment,.tts,.ads,.advertisement").remove();

    var html = el.html();
    html = html.replace(/<h1[^>]*>[\s\S]*?<\/h1>/gi, "")
               .replace(/<h2[^>]*>[\s\S]*?<\/h2>/gi, "")
               .replace(/<h3[^>]*>[\s\S]*?<\/h3>/gi, "")
               .replace(/Chương trước|Chương tiếp|TRÌNH ĐỌC TTS|Đang tải giọng đọc/gi, "");

    return Response.success(html);
}